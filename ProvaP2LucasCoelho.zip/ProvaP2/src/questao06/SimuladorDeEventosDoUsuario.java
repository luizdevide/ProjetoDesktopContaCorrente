/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package questao06;

/**
 *
 * @author Coelho
 */
public class SimuladorDeEventosDoUsuario {
    //os metodos a seguir retornaram true se conseguirem fazer a operação e
    //false, caso contrario
    
    public boolean edit(){
        return true;
    }
    public boolean goToLine() {
        return true;
    }
    public boolean lineNumber(){
        return true;
    }
    public boolean cancel(){
        return true;
    }
    public boolean ok(){
        return true;
    }
    public boolean cut(){
        return true;
    }
    public boolean copy(){
        return true;
    }
    public boolean paste(){
        return true;
    }
    
    //TODO implemente os métodos para os outros eventos

}
